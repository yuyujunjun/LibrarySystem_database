#ifndef GRAPHIC_H
#define GRAPHIC_H
#include <QMessageBox>
#include "mainwindow.h"
#include"logindialog.h"
void graphic();
#endif // GRAPHIC_H
