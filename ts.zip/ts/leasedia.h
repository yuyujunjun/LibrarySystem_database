#ifndef LEASEDIA_H
#define LEASEDIA_H

#include <QDialog>
#include<QString>
namespace Ui {
class LeaseDIA;
}

class LeaseDIA : public QDialog
{
    Q_OBJECT

public:
    explicit LeaseDIA(QWidget *parent = 0);
    ~LeaseDIA();
    QString user;
private slots:
    void on_pushButton_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::LeaseDIA *ui;
};

#endif // LEASEDIA_H
