#include "returnbook.h"
#include "ui_returnbook.h"
#include"all.h"
returnbook::returnbook(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::returnbook)
{
    ui->setupUi(this);
}

returnbook::~returnbook()
{
    delete ui;
}



void returnbook::on_show_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel;
    model->setQuery("select * from borrow where cno='"+user+"'");//这里直接设置SQL语句，忽略最后一个参数
    ui->tableView->setModel(model);

    //以下是视觉方面的效果，不加也没影响

    //隔行变色
    ui->tableView->setAlternatingRowColors(true);

    //设置行高
    int row_count = model->rowCount();
    for(int i =0; i < row_count; i++)
    {
        ui->tableView->setRowHeight(i, 20);
    }
}

void returnbook::on_return_2_clicked()
{
    QSqlQuery query;
    query.exec("select count(*)as num from borrow where bno='"+ui->lineEdit->text()+"'");
    query.first();
    int borrowed=query.value("num").toInt();
    if(borrowed>0){
        query.exec("delete from borrow where bno='"+ ui->lineEdit->text()+"'");
        query.exec("update book set stock=stock+1 where bno='"+ui->lineEdit->text()+"'");
         on_show_clicked();
        QMessageBox::warning(this, tr("success"),
                              tr("you have returned the book"),
                              QMessageBox::Yes);

    }else{
        QMessageBox::warning(this, tr("warning"),
                              tr("you can't return since you don't have this book"),
                              QMessageBox::Yes);
    }
}

void returnbook::on_back_clicked()
{
    UserUI *u=new UserUI;
    u->user=user;
    u->show();
    this->close();
}
