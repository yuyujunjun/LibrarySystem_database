#ifndef USERUI_H
#define USERUI_H
#include"all.h"
#include <QDialog>
#include<QString>
#include "userui.h"
#include "ui_userui.h"
namespace Ui {
class UserUI;
}

class UserUI : public QDialog
{
    Q_OBJECT

public:
    explicit UserUI(QWidget *parent = 0);
    ~UserUI();
    QString user;
private slots:
    void on_pushButton_clicked();



    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::UserUI *ui;
};

#endif // USERUI_H



