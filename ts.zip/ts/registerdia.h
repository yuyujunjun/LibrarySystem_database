#ifndef REGISTERDIA_H
#define REGISTERDIA_H

#include <QDialog>
#include<QString>
namespace Ui {
class RegisterDia;
}

class RegisterDia : public QDialog
{
    Q_OBJECT

public:
    explicit RegisterDia(QWidget *parent = 0);
    ~RegisterDia();
    QString user;

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::RegisterDia *ui;
    QString type;
};

#endif // REGISTERDIA_H
