#include"all.h"
#include "adminui.h"
#include "ui_adminui.h"
LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    ui->setupUi(this);
}

LoginDialog::~LoginDialog()
{
    delete ui;
}

void LoginDialog::on_pushButton_clicked()
{

    QSqlQuery query;

    query.exec("select password from card where cno='"+ui->userLineEdit->text()+"'");
    query.first();
    QString pwd=query.value("password").toString();
    query.exec("select type from card where cno='"+ui->userLineEdit->text()+"'");
    query.first();
    QString type=query.value("type").toString();
       if(ui->pwdLineEditor->text()!=NULL&&ui->userLineEdit->text()!=NULL&&ui->pwdLineEditor->text() == pwd)
       {
           if(type=="S"||type=="T")
              {
               UserUI *w=new UserUI;
               w->show();
               w->user=ui->userLineEdit->text();
           }
           else{
               adminUI *w=new adminUI;
               w->user=ui->userLineEdit->text();
               w->show();
           }
          this->close();
       } else {
          QMessageBox::warning(this, tr("Waring"),
                                tr("user name or password error!"),
                                QMessageBox::Yes);
       }

}

void LoginDialog::on_pushButton_3_clicked()
{
    RegisterDia *dlg=new RegisterDia;
    dlg->show();
    this->close();
}
