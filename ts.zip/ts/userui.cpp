#include"all.h"
#include "userui.h"
#include "ui_userui.h"
#include "returnbook.h"
#include "ui_returnbook.h"
#include "search.h"
#include "ui_search.h"
UserUI::UserUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserUI)
{
    ui->setupUi(this);
}

UserUI::~UserUI()
{
    delete ui;
}
void UserUI::on_pushButton_clicked()
{
    LeaseDIA *x=new LeaseDIA;
    x->user=user;
    x->show();
    this->close();
}
void UserUI::on_pushButton_2_clicked()
{
      returnbook *w=new returnbook;
      w->user=user;
      w->show();;
      this->close();
}
void UserUI::on_pushButton_3_clicked()
{
    search *a=new search;
    a->user=user;
    a->show();
    this->close();
}
