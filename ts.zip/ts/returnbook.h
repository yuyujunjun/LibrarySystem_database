#ifndef RETURNBOOK_H
#define RETURNBOOK_H

#include <QDialog>

namespace Ui {
class returnbook;
}

class returnbook : public QDialog
{
    Q_OBJECT

public:
    explicit returnbook(QWidget *parent = 0);
    ~returnbook();
    QString user;
private slots:


    void on_show_clicked();

    void on_return_2_clicked();

    void on_back_clicked();

private:
    Ui::returnbook *ui;
};

#endif // RETURNBOOK_H
