#ifndef ADMINUI_H
#define ADMINUI_H

#include <QDialog>

namespace Ui {
class adminUI;
}

class adminUI : public QDialog
{
    Q_OBJECT

public:
    explicit adminUI(QWidget *parent = 0);
    ~adminUI();
    QString user;

private:
    Ui::adminUI *ui;
};

#endif // ADMINUI_H
