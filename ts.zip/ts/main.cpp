#include"all.h"
//这个是手工添加的函数
void OpenDatabase()
{
    QSqlDatabase db=QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("test");
    //db.setDatabaseName(QString("Driver={sql server};server=(localdb)\MSSQLLocalDB;database=library;" )  );
    if (!db.open())
    {
        QMessageBox::critical(0, qApp->tr("Cannot open database"),
                              db.lastError().databaseText(), QMessageBox::Cancel);

    }
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    LoginDialog x;
    OpenDatabase();
    x.show();

    //打开数据库



    //qDebug()<< pwd;

    /*query.exec("insert into book values('20', N'生物学',N'物种起源',N'哈佛大学',2002,'Darwin',48.00,20,4 )");
    query.exec("select * from book");
    while(query.next()){
        int name=query.value("bno").toInt();
        QString name2=query.value("category").toString();
        qDebug()<<name<<name2;
    }
query.exec("delete from book where bno=10");*/
    return a.exec();
}
