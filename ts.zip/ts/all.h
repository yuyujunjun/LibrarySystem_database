#ifndef ALL_H
#define ALL_H
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"logindialog.h"
#include "ui_logindialog.h"
#include "registerdia.h"
#include "ui_registerdia.h"
#include "userui.h"
#include "ui_userui.h"
#include "leasedia.h"
#include "ui_leasedia.h"
#include "adminui.h"
#include "ui_adminui.h"
#include <QApplication>
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QSqlError>
#include <QMessageBox>
#include<QString>
#include<QDebug>
#include <QTextEdit>
#include <QSqlQueryModel>
#include <QTableView>

#include<QDateTime>
#endif // ALL_H
