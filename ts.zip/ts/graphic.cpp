#include"graphic.h"
void graphic(){
    MainWindow w;
    LoginDialog x;

    if(x.exec()==QDialog::Accepted)
    w.show();
}
