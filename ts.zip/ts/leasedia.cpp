#include"all.h"
#include "leasedia.h"
#include "ui_leasedia.h"
#include "search.h"
#include "ui_search.h"
#include <QTableView>
LeaseDIA::LeaseDIA(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LeaseDIA)
{
    ui->setupUi(this);
}

LeaseDIA::~LeaseDIA()
{
    delete ui;
}

void LeaseDIA::on_pushButton_clicked()
{

    QDateTime ctime = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = ctime.toString("yyyy-MM-dd"); //设置显示格式
     QDateTime mtime=QDateTime::currentDateTime().addMonths(1);
     QString str1 = mtime.toString("yyyy-MM-dd");
    QSqlQuery query;
    int stock;
    query.exec("select stock from book where bno='"+ui->bno->text()+"'");//查看库存
    query.first();
    stock=query.value("stock").toInt();
    int borrowing;
    query.exec("select count(*)as num from borrow where cno='"+this->user+"'");
    query.first();
    borrowing=query.value("num").toInt();
    if(stock>=1&&borrowing<2){
        query.exec("insert into borrow values('"+this->user+"','"+ui->bno->text()+"','"+str+"','"+str1+"')");
        query.exec("update book set stock=stock-1 where bno='"+ui->bno->text()+"'");
        query.exec("select count(*)as num from borrow where cno='"+this->user+"'and bno='"+ui->bno->text()+"'");
        query.first();
        int isexist=query.value("num").toInt();
        if(isexist){
            QMessageBox::warning(this, tr("success"),
                                  tr("success leasing"),
                                  QMessageBox::Yes);
            on_pushButton_4_clicked();
        }else {
            QMessageBox::warning(this, tr("Waring"),
                                  tr("the bno is wrong"),
                                  QMessageBox::Yes);
        }
    }else{

        if(stock<1){
            query.exec("select max(return_date)as time from borrow where bno='"+ ui->bno->text()+"'");
            query.first();
            QString date=query.value("time").toString();
            date="the earliest return date is:"+date;
            QMessageBox::warning(this, tr("Waring. the stock is empty"),
                                            tr(qPrintable(date)),
                                         QMessageBox::Yes);
        }
        else {
            QMessageBox::warning(this, tr("Waring"),
                                   tr(" you have already lease 2 books"),
                                   QMessageBox::Yes);
        }
    }
    query.first();
}


void LeaseDIA::on_pushButton_4_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel;
    model->setQuery("select * from borrow where cno='"+user+"'");//这里直接设置SQL语句，忽略最后一个参数
    ui->tableView->setModel(model);

    //以下是视觉方面的效果，不加也没影响

    //隔行变色
    ui->tableView->setAlternatingRowColors(true);

    //设置行高
    int row_count = model->rowCount();
    for(int i =0; i < row_count; i++)
    {
        ui->tableView->setRowHeight(i, 20);
    }
}

void LeaseDIA::on_pushButton_2_clicked()
{
    UserUI * u=new UserUI;
    u->user=user;
    u->show();
    this->close();
}

void LeaseDIA::on_pushButton_3_clicked()
{
    search *a =new search;
    a->user=user;
    a->show();

}
