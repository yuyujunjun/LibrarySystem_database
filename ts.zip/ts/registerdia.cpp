#include"all.h"
RegisterDia::RegisterDia(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RegisterDia)
{
    ui->setupUi(this);
}

RegisterDia::~RegisterDia()
{
    delete ui;
}

void RegisterDia::on_pushButton_2_clicked()
{
    LoginDialog *back=new LoginDialog;
    back->show();
    this->close();
}

void RegisterDia::on_pushButton_clicked()
{
    QSqlQuery query;
    query.exec("select count(*)as num from card where cno='"+ui->user->text()+"'");
    query.first();
    int isexist=query.value("num").toInt();
    if(!ui->user->text().isEmpty()&&!ui->pwd->text().isEmpty()&&!ui->department->text().isEmpty()&&!ui->name->text().isEmpty()&&!isexist)
    {
        QString type;
        int flag=0;
        if(ui->T->isChecked())type="T";
        else if(ui->S->isChecked())type="S";
        else if(ui->A->isChecked())type="A";
        else {
            flag=1;
            QMessageBox::warning(this, tr("Warning"),
                                  tr("you need choose an indentity!"),
                                  QMessageBox::Yes);
        }
        if(flag==0){
            query.exec("insert into card values('"+ui->user->text()+"','"+ui->pwd->text()+"','"+ui->name->text()+"','"+ui->department->text()+"','"+type+"')");
            query.exec("select count(*)as num from card where cno='"+ui->user->text()+"'");
            query.first();
            isexist=query.value("num").toInt();
            if(isexist)
            QMessageBox::warning(this, tr("success"),
                                  tr("regesiter success"),
                                  QMessageBox::Yes);
            else QMessageBox::warning(this, tr("failure"),
                                      tr("you can not write in database"),
                                      QMessageBox::Yes);
            LoginDialog *back=new LoginDialog;
            back->show();
            this->close();
        }
     }else {
       QMessageBox::warning(this, tr("Warning"),
                             tr("user name or password error!"),
                             QMessageBox::Yes);
    }
}
