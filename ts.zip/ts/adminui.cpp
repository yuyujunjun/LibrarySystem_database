#include "adminui.h"
#include "ui_adminui.h"

adminUI::adminUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::adminUI)
{
    ui->setupUi(this);
}

adminUI::~adminUI()
{
    delete ui;
}
